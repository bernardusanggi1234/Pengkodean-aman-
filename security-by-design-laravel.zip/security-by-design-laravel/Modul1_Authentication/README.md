# Modul 1 — Authentication & Login Security

## Masalah yang Ditemukan

| No | Masalah | Lokasi |
|----|---------|--------|
| 1 | Tidak ada tracking login attempts → brute force bebas | `AuthController::login()` |
| 2 | Tidak ada lockout mechanism | `AuthController::login()` |
| 3 | Session tidak di-bind ke IP/device | `AuthController::login()` |
| 4 | Shallow model — User hanya data container | `User.php` |
| 5 | Tidak ada audit trail percobaan login | Semua file |

## Konsep yang Diterapkan

- **Deep Model** — business logic lockout dipindah ke dalam model `User`
- **Audit Trail** — setiap percobaan login dicatat di tabel `login_attempts`
- **Session Ownership** — session di-bind ke IP login

## File

| File | Keterangan |
|------|------------|
| `AuthController_before.php` | Kode bermasalah |
| `User_before.php` | Model sebelum perbaikan |
| `AuthController_after.php` | Kode setelah perbaikan |
| `User_after.php` | Deep Model setelah perbaikan |
| `LoginAttempt.php` | Model audit trail baru |
| `migrations/` | Migration untuk tabel baru |
