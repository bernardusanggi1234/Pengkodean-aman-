<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

/**
 * KODE DIPERBAIKI — Deep Model
 *
 * Konsep: Deep Model
 * Business logic keamanan dipindah masuk ke dalam model.
 * Model User sekarang "tahu" kapan dirinya harus dikunci.
 * Controller hanya memanggil metode semantik,
 * tidak lagi mengubah field secara langsung.
 */
class User extends Authenticatable
{
    use HasApiTokens;

    protected $fillable = ['name', 'email', 'password'];

    protected $casts = [
        'locked_until'          => 'datetime',
        'failed_login_attempts' => 'integer',
    ];

    public function isLocked(): bool
    {
        return $this->locked_until !== null
            && $this->locked_until->isFuture();
    }

    public function lockUntil(Carbon $until): void
    {
        $this->locked_until = $until;
        $this->save();
    }

    public function canAttemptLogin(): bool
    {
        return !$this->isLocked();
    }

    public function incrementFailedAttempts(): void
    {
        $this->failed_login_attempts++;

        if ($this->failed_login_attempts >= 5) {
            $this->lockUntil(now()->addMinutes(15));
        }

        $this->save();
    }

    public function clearFailedAttempts(): void
    {
        $this->failed_login_attempts = 0;
        $this->locked_until          = null;
        $this->save();
    }
}
