<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * KODE BERMASALAH
 *
 * Masalah:
 * 1. Tidak ada rate limiting — bisa brute force berkali-kali
 * 2. Session tidak di-bind ke device/IP — token bisa dicuri
 * 3. Tidak ada audit trail percobaan login
 */
class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        // MASALAH: Tidak ada rate limiting, bisa brute force berkali-kali
        if (!Auth::attempt($credentials)) {
            return back()->withErrors(['email' => 'Invalid credentials']);
        }

        // MASALAH: Session tidak di-bind ke device/IP, token bisa dicuri
        $request->session()->regenerate();

        return redirect()->intended('dashboard');
    }
}
