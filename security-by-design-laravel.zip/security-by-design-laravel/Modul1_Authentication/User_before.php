<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * KODE BERMASALAH — Shallow Model (Anemic Domain Model)
 *
 * Masalah:
 * - User hanya data container, zero business logic
 * - Tidak ada: isLocked(), lockUntil(), incrementFailedAttempts(), dll.
 * - Semua logika keamanan terpaksa tersebar di controller
 */
class User extends Authenticatable
{
    protected $fillable = ['name', 'email', 'password'];
}
