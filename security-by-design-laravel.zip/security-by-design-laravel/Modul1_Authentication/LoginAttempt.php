<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Model Audit Trail untuk mencatat setiap percobaan login.
 *
 * Konsep: Audit Trail
 * - Setiap percobaan login dicatat lengkap dengan IP dan timestamp
 * - shouldLockout() mengecek window 15 menit terakhir
 *   sehingga user yang salah password minggu lalu tidak terkena lockout hari ini
 */
class LoginAttempt extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'email',
        'ip_address',
        'user_agent',
        'success',
        'attempted_at',
    ];

    protected $casts = [
        'success'      => 'boolean',
        'attempted_at' => 'datetime',
    ];

    public static function recordFailure(string $email, string $ip): void
    {
        static::create([
            'email'        => $email,
            'ip_address'   => $ip,
            'success'      => false,
            'attempted_at' => now(),
        ]);
    }

    public static function recordSuccess(string $email, string $ip): void
    {
        static::create([
            'email'        => $email,
            'ip_address'   => $ip,
            'success'      => true,
            'attempted_at' => now(),
        ]);
    }

    /**
     * Cek apakah email ini harus di-lockout.
     * >= 5 gagal dalam 15 menit terakhir → harus lockout.
     */
    public static function shouldLockout(string $email): bool
    {
        return static::where('email', $email)
            ->where('success', false)
            ->where('attempted_at', '>=', now()->subMinutes(15))
            ->count() >= 5;
    }

    public static function clearAttempts(string $email): void
    {
        static::where('email', $email)
            ->where('success', false)
            ->delete();
    }
}
