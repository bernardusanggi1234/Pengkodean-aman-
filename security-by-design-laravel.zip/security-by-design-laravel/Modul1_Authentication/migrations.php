<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ============================================================
// Migration 1: Tabel login_attempts (Audit Trail)
// ============================================================
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('login_attempts', function (Blueprint $table) {
            $table->id();
            $table->string('email')->index();
            $table->string('ip_address');
            $table->text('user_agent')->nullable();
            $table->boolean('success')->default(false);
            $table->timestamp('attempted_at');
            $table->index(['email', 'attempted_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('login_attempts');
    }
};

// ============================================================
// Migration 2: Tambah kolom ke tabel users
// ============================================================
// return new class extends Migration
// {
//     public function up(): void
//     {
//         Schema::table('users', function (Blueprint $table) {
//             $table->timestamp('locked_until')->nullable();
//             $table->integer('failed_login_attempts')->default(0);
//         });
//     }
//
//     public function down(): void
//     {
//         Schema::table('users', function (Blueprint $table) {
//             $table->dropColumn(['locked_until', 'failed_login_attempts']);
//         });
//     }
// };
