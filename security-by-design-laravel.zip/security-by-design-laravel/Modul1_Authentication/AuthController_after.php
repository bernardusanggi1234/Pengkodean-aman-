<?php

namespace App\Http\Controllers;

use App\Models\LoginAttempt;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * KODE DIPERBAIKI
 *
 * Perbaikan:
 * 1. Dua lapis pengecekan lockout — dari tabel login_attempts dan dari model User
 * 2. Jika login gagal, keduanya diupdate sekaligus
 * 3. Session di-bind ke IP (Session Ownership)
 * 4. Token Sanctum dibuat setelah login berhasil
 */
class AuthController extends Controller
{
    public function login(Request $request)
    {
        $email = $request->input('email');
        $ip    = $request->ip();

        // Cek riwayat attempts — lockout berbasis waktu (15 menit)
        if (LoginAttempt::shouldLockout($email)) {
            return response()->json([
                'message' => 'Account locked. Try again in 15 minutes.',
            ], 429);
        }

        $user = User::where('email', $email)->first();

        // Cek lockout di level model User
        if ($user && $user->isLocked()) {
            return response()->json([
                'message' => 'Account locked. Try again in 15 minutes.',
            ], 429);
        }

        if (!Auth::attempt(['email' => $email, 'password' => $request->input('password')])) {
            LoginAttempt::recordFailure($email, $ip);

            if ($user) {
                $user->incrementFailedAttempts();
            }

            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        // Berhasil — bersihkan semua catatan gagal
        LoginAttempt::recordSuccess($email, $ip);
        LoginAttempt::clearAttempts($email);

        Auth::user()->clearFailedAttempts();

        $request->session()->regenerate();
        $request->session()->put('login_ip', $ip); // IP binding

        $token = Auth::user()->createToken('auth-token')->plainTextToken;

        return response()->json([
            'message' => 'Login successful',
            'token'   => $token,
        ]);
    }
}
