<?php

namespace App\Models;

use App\Events\VoucherRedeemed;
use App\ValueObjects\VoucherCode;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * KODE DIPERBAIKI — Idempotency + Pessimistic Locking + Domain Validation
 *
 * Perbaikan:
 * 1. Idempotency Key — request yang sama dua kali tidak membuat duplikat redemption
 * 2. Pessimistic Locking via lockForUpdate() — race condition dicegah di level DB
 * 3. Double-check setelah lock — validasi dipanggil ulang setelah row ter-lock
 * 4. usage_count di-guard — tidak bisa diubah manual dari luar
 * 5. Field kritis immutable setelah dibuat (code, max_usage, valid_from)
 */
class Voucher extends Model
{
    // usage_count di-guard — tidak bisa diubah manual dari luar
    protected $guarded = ['id', 'usage_count'];

    protected $casts = [
        'is_active'           => 'boolean',
        'is_first_order_only' => 'boolean',
        'valid_from'          => 'datetime',
        'valid_until'         => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();

        // Validasi domain saat membuat voucher baru
        static::creating(function (Voucher $voucher) {
            $voucher->code = VoucherCode::fromString($voucher->code)->toString();

            if ($voucher->discount_value <= 0) {
                throw new \InvalidArgumentException('discount_value must be positive.');
            }

            if ($voucher->max_usage <= 0) {
                throw new \InvalidArgumentException('max_usage must be greater than 0.');
            }

            if ($voucher->valid_until <= $voucher->valid_from) {
                throw new \InvalidArgumentException('valid_until must be after valid_from.');
            }
        });

        // Cegah perubahan field kritis setelah voucher dibuat
        static::updating(function (Voucher $voucher) {
            foreach (['code', 'max_usage', 'valid_from'] as $field) {
                if (array_key_exists($field, $voucher->getDirty())) {
                    throw new \Exception("Field '{$field}' is immutable after creation.");
                }
            }
        });
    }

    /**
     * Cek semua kondisi sebelum redemption.
     * Return [bool $canRedeem, ?string $reason]
     */
    public function canBeRedeemed(User $user, Order $order): array
    {
        if (!$this->is_active) {
            return [false, 'Voucher is not active'];
        }

        if (now()->lt($this->valid_from) || now()->gt($this->valid_until)) {
            return [false, 'Voucher has expired'];
        }

        if ($this->usage_count >= $this->max_usage) {
            return [false, 'Voucher has been fully used'];
        }

        if ($this->min_purchase && $order->amount < $this->min_purchase) {
            return [false, 'Minimum purchase not met'];
        }

        if ($this->is_first_order_only) {
            $hasOtherOrders = Order::where('user_id', $user->id)
                ->where('id', '!=', $order->id)
                ->exists();

            if ($hasOtherOrders) {
                return [false, 'Voucher only for first order'];
            }
        }

        return [true, null];
    }

    /**
     * Redeem voucher dengan Idempotency Key dan Pessimistic Locking.
     */
    public function redeem(
        User   $user,
        Order  $order,
        string $idempotencyKey,
        int    $discountCents,
        string $ip
    ): VoucherRedemption {
        // Cek idempotency — request yang sama tidak akan double redeem
        $existing = VoucherRedemption::where('idempotency_key', $idempotencyKey)->first();
        if ($existing) {
            return $existing;
        }

        return DB::transaction(function () use ($user, $order, $idempotencyKey, $discountCents, $ip) {
            // Pessimistic lock — cegah race condition
            $voucher = Voucher::lockForUpdate()->find($this->id);

            // Double-check setelah lock
            [$canRedeem, $reason] = $voucher->canBeRedeemed($user, $order);
            if (!$canRedeem) {
                throw new \DomainException($reason);
            }

            // Increment langsung di DB untuk bypass guarded
            DB::table('vouchers')->where('id', $voucher->id)->increment('usage_count');

            $redemption = VoucherRedemption::create([
                'voucher_id'      => $voucher->id,
                'user_id'         => $user->id,
                'order_id'        => $order->id,
                'idempotency_key' => $idempotencyKey,
                'discount_amount' => $discountCents,
                'ip_address'      => $ip,
                'redeemed_at'     => now(),
            ]);

            event(new VoucherRedeemed($voucher, $user));

            return $redemption;
        });
    }
}
