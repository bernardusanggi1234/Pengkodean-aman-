<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Voucher;
use App\Services\VoucherRedemptionService;
use App\ValueObjects\VoucherCode;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * KODE DIPERBAIKI — Thin Controller
 *
 * Perbaikan:
 * 1. Idempotency key diambil dari header X-Idempotency-Key
 *    → client retry tidak menghasilkan double redemption
 * 2. VoucherCode::fromString() memvalidasi format kode sebelum query DB
 * 3. Semua domain logic ada di Voucher model dan VoucherRedemptionService
 *
 * checkUsage() DIHAPUS TOTAL:
 * Endpoint ini adalah security risk — mengekspos usage_count dan max_usage
 * yang bisa dipakai attacker untuk enumerate dan brute-force kode voucher.
 */
class VoucherController extends Controller
{
    public function __construct(private VoucherRedemptionService $redemptionService) {}

    public function redeem(Request $request)
    {
        $validated = $request->validate([
            'code'     => 'required|string',
            'order_id' => 'required|exists:orders,id',
        ]);

        $user  = auth()->user();
        $order = Order::findOrFail($validated['order_id']);

        // Ambil dari header atau generate UUID baru
        $idempotencyKey = $request->header('X-Idempotency-Key') ?? Str::uuid()->toString();

        try {
            $voucherCode = VoucherCode::fromString($validated['code']);

            $result = $this->redemptionService->redeemVoucher(
                $voucherCode,
                $user,
                $order,
                $idempotencyKey,
                $request->ip()
            );
        } catch (\InvalidArgumentException $e) {
            return response()->json(['message' => 'Invalid voucher code format'], 422);
        } catch (\DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json([
            'message'  => 'Voucher applied',
            'discount' => $result['discount'],
        ]);
    }

    // checkUsage() DIHAPUS TOTAL
    // Endpoint ini adalah enumeration attack vector:
    // attacker bisa brute-force kode voucher satu per satu
    // dan mendapat konfirmasi mana yang valid dari response-nya.
}
