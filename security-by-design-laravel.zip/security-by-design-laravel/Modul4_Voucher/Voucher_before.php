<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * KODE BERMASALAH — Primitive Obsession + Boolean Flag Hell
 *
 * Masalah:
 * 1. usage_count bisa diubah langsung dari luar (ada di $fillable)
 * 2. Boolean flag hell — is_active=true tapi is_expired=true bisa terjadi bersamaan
 * 3. Tidak ada validasi domain
 * 4. Tidak ada method redemption
 */
class Voucher extends Model
{
    // MASALAH: Semua field fillable termasuk usage_count
    protected $fillable = [
        'code',
        'discount_type',
        'discount_value',
        'usage_count',   // Bisa dimanipulasi langsung dari luar!
        'max_usage',
        'valid_from',
        'valid_until',
    ];

    // MASALAH: Boolean flag hell
    protected $casts = [
        'is_active'           => 'boolean',
        'is_expired'          => 'boolean',  // Bisa is_active=true tapi is_expired=true
        'is_used_up'          => 'boolean',
        'is_first_order_only' => 'boolean',
        'is_stackable'        => 'boolean',
        'is_reusable'         => 'boolean',
    ];

    // Tidak ada validasi domain, tidak ada method redemption
}
